﻿using System;

namespace MokAssesment_Question_3
{
    class Author
    {
        string name;
        string email;
        char gender;

        public Author(string name, string email, Char gender)
        {
            this.name = name;
            SetEmail(email);
            this.gender = gender;
        }

        public string GetName()
        {
            return name;
        }

        public string GetEmail()
        {
            return email;
        }

        public void SetEmail(string InputEmail)
        {
            this.email = InputEmail;
        }

        public char GetGender()
        {
            return gender;
        }

        public override string ToString()
        {
            return $"Author[name={name},email={email},gender={gender}]";
        }

    }
    
    class TestAuthor
    {
        static void Main(string[] args)
        {
            Author a = new Author("Tarun", "tarun@ssl.com", 'm');
            Console.WriteLine(a);
        }
    }
}
