﻿using System;

namespace Csharp_PracticalAssesment
{
    /// <summary>
    /// Driver class for the application
    /// Test Case -- User Input along with Try Catch Block
    /// Test Case -- To check working of Change of Address
    /// ...Tried User Menu Driven Approach... 
    /// </summary>
    
    class UsingPeople
    {
        public static void Main(string[] args)
        {
            /// <summary>
            /// Test Case -- User Input along with Try Catch Block
            /// </summary>

            try
            {
                Console.Write("Enter Employee ID: ");
                int Id = int.Parse(Console.ReadLine());

                Console.Write("Enter Employee Name: ");
                string Name = Console.ReadLine();

                Console.Write("Enter Address: ");
                string Address = Console.ReadLine();

                Console.Write("Enter Number of skill:");
                int n = int.Parse(Console.ReadLine());

                Console.WriteLine("Enter Skills: ");
                string[] InputSkills = new string[n];
                for (int i = 0; i < n; i++)
                    InputSkills[i] = Console.ReadLine();

                Console.WriteLine("\n");

                TechnicalEmployee TechEmp_1 = new TechnicalEmployee(Id, Name, Address, InputSkills);
                Console.WriteLine(TechEmp_1);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("You have Entered a wrong Format... Enter as Intger Format...");
            }
            catch  (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            Console.WriteLine("\n---------------------------------------------------------------------------------\n");

            try
            {
                Console.Write("Enter Staff ID: ");
                int Id = int.Parse(Console.ReadLine());

                Console.Write("Enter Staff Name: ");
                string Name = Console.ReadLine();

                Console.Write("Enter Address: ");
                string Address = Console.ReadLine();

                Console.Write("Enter Title:");
                string Title = Console.ReadLine();


                Console.WriteLine("\n");

                StaffMember StaffMem = new StaffMember(Id, Name, Address, Title);
                Console.WriteLine(StaffMem.ToString());
            }
            catch (FormatException)
            {
                Console.WriteLine("You have Entered a wrong Format... Enter as Intger Format...");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


            //TechnicalEmployee TechEmp_1 = new TechnicalEmployee(20256, "Vignesh", "Chettinad, TamilNadu", new string[] { "C#", "Java", "MATLAB" });
            //Console.WriteLine(TechEmp_1);
            //Console.WriteLine("\n---------------------------------------------------------------------------------\n");
            //StaffMember StaffMem = new StaffMember(1001, "Vicky", "Trichy, TamilNadu", "House Keeping");
            //Console.WriteLine(StaffMem);


            /// <summary>
            /// Test Case -- To check working of Change of Address
            /// </summary>

            //TechnicalEmployee TechEmp = new TechnicalEmployee(20256, "Vignesh", "Chettinad, TamilNadu", new string[] { "C#", "Java", "MATLAB" });
            //Console.WriteLine(TechEmp);
            //Console.WriteLine("\n---------------------------------------------------------------------------------\n");
            //TechEmp.SetAddress("Bangalore, Karnataka");
            //Console.WriteLine(TechEmp);

            /// <summary>
            /// Tried User Menu Driven Approach... 
            /// </summary>

            //bool Disp = true;
            //while (Disp == true)
            //{
            //    Disp = Display();

            //}

            //static bool Display()
            //{
            //    Console.Clear();
            //    Console.WriteLine("Enter the Number: ");
            //    Console.WriteLine("1. Technical Employee");
            //    Console.WriteLine("2. Staff Member");
            //    Console.WriteLine("3. Exit ");
            //    string choice = Console.ReadLine();

            //    if (choice == "1")
            //    {
            //        Tech();
            //        return true;
            //    }

            //    else if (choice == "2")
            //    {
            //        Staff();
            //        return true;
            //    }

            //    else if (choice == "3")
            //        return false;

            //    else
            //        return true;
            //}

            //static void Tech()
            //{
            //    Console.Clear();

            //    Console.Write("Enter Employee ID: ");
            //    int Id = int.Parse(Console.ReadLine());

            //    Console.Write("Enter Employee Name: ");
            //    string Name = Console.ReadLine();

            //    Console.Write("Enter Address: ");
            //    string Address = Console.ReadLine();

            //    Console.WriteLine("Enter Skills (max 10): ");
            //    string[] InputSkills = new string[10];
            //    for (int i = 0; i < 10; i++)
            //        InputSkills[i] = Console.ReadLine();

            //    TechnicalEmployee TechEmp_1 = new TechnicalEmployee(Id, Name, Address, InputSkills);
            //    Console.WriteLine(TechEmp_1);

            //}

            //static void Staff()
            //{
            //    Console.Clear();

            //    Console.Write("Enter Employee ID: ");
            //    int Id = int.Parse(Console.ReadLine());

            //    Console.Write("Enter Employee Name: ");
            //    string Name = Console.ReadLine();

            //    Console.Write("Enter Address: ");
            //    string Address = Console.ReadLine();

            //    Console.Write("Enter Title: ");
            //    string Title = Console.ReadLine();

            //    StaffMember StaffMem = new StaffMember(Id, Name, Address, Title);
            //    Console.WriteLine(StaffMem.ToString());

            //}

        }
    }
}
