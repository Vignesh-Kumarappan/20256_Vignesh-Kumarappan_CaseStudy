﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_PracticalAssesment
{
    /// <summary>
    /// Technical Employee class Created. It inherts Employee Class...
    /// Calculates Salary of Technical Employee and returns...
    /// </summary>
    
    class TechnicalEmployee : Employee
    {
        string[] Skills;
        double Salary;

        public TechnicalEmployee(int EmployeeId, string EmployeeName, string Address, string[] Skills) : base(EmployeeId, EmployeeName, Address)  // Constructor...
        {
            this.Skills = Skills;
        }

        double GetHRA()    // Returns HRA of the technical Employee...
        {
            return (0.12 * Tech_BasicPay);
        }

        public override double calculateSalary()   // OverRides abstract method and returns the salary of Technical Employee...
        {
            Salary = Tech_BasicPay + GetHRA();
            return Salary;
        }
        public override string ToString()  // Return base class ToString() and TechnicalEmployee Class Tostring()...
        {
            return base.ToString() + $"\nSkills of Employee \t -- {string.Join(", ", Skills)}" + $"\nSalary of Employee \t -- {calculateSalary()}" ;
        }
    }
}
