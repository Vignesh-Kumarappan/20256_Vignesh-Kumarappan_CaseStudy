﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_PracticalAssesment
{

    /// <summary>
    /// Staff Member class Created. It inherts Employee Class...
    /// Calculates Salary of Staff member and returns...
    /// </summary>

    class StaffMember : Employee
    {
        string Title;
        double Salary;

        public StaffMember(int EmployeeId, string EmployeeName, string Address, string Title) : base(EmployeeId, EmployeeName, Address) // Constructor...
        {
            this.Title = Title;
        }

        double GetHRA()    // Returns HRA of the Staff member...
        {
            return (0.12 * Staff_BasicPay);
        }

        public override double calculateSalary()   // OverRides abstract method and returns the salary of Staff member...
        {
            Salary = Staff_BasicPay + GetHRA();
            return Salary;
        }

        public override string ToString()  // Return base class ToString() and TechnicalEmployee Class Tostring()...
        {
            return base.ToString() + $"\nStaff Member Title \t -- {Title}" + $"\nSalary of Staff Member \t -- {calculateSalary()}";
        }
    }
}
