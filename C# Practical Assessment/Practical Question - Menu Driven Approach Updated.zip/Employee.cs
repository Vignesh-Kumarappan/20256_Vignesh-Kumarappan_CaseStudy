﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Csharp_PracticalAssesment
{
    /// <summary>
    /// Creating an abstract Class for Employee and abstract method calculateSalary...
    /// </summary>

    public abstract class Employee
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        string Address;
        public double Tech_BasicPay = 50000;
        public double Staff_BasicPay = 10000;


        public Employee(int EmployeeId, string EmployeeName, string Address) // Basic Pay is set by Company... User Cant Enter it...
        {
            this.EmployeeId = EmployeeId;
            this.EmployeeName = EmployeeName;
            SetAddress(Address);
        }

        public string GetAddress()  // Return Address of the Employee...
        {
            return Address;
        }

        public void SetAddress(string Add)   // As address can be changed by the user anytime...
        {
            this.Address = Add;
        }

        abstract public double calculateSalary();  // Abstract method is created -- overriden in the inherted classes...

        public override string ToString()    // Retuens Name & Id of the employee...
        {
            return $"Employee ID \t\t -- {EmployeeId}" + $"\nEmployee Name \t\t -- {EmployeeName}" + $"\nAddress \t\t -- {GetAddress()}";
        }

    }
       
}
