﻿using System;

namespace Csharp_PracticalAssesment
{
    /// <summary>
    /// Driver class for the applicatio
    /// ...Tried User Menu Driven Approach... 
    /// ...Option to Change Address provided..
    /// ... Exceptions are handled using Try Catch block...
    /// </summary>
    
    class UsingPeople
    {
        public static void Main(string[] args)
        {
            
            /// <summary>
            /// Menu Driven Approach... 
            /// 
            /// Has option to change address...
            /// Exceptions are handled...
            /// </summary>


            int Id;
            string Name;
            string Address;
            string Title;
            string[] InputSkills;
            int n;

            bool Disp = true;
            while (Disp == true)
            {
                Disp = Display();
                Console.WriteLine("\n");
            }

            bool Display()
            {
                
                Console.WriteLine("Enter the Number: ");
                Console.WriteLine("1. Technical Employee");
                Console.WriteLine("2. Staff Member");
                Console.WriteLine("3. Exit ");
                string choice = Console.ReadLine();
                Console.WriteLine("\n");

                if (choice == "1")
                {
                    Tech();
                    return true;
                }

                else if (choice == "2")
                {
                    Staff();
                    return true;
                }

                else if (choice == "3")
                    return false;

                else
                    return true;
            }

            void Tech()
            {
                try
                {
                    Console.Write("Enter Employee ID: ");
                    Id = int.Parse(Console.ReadLine());

                    Console.Write("Enter Employee Name: ");
                    Name = Console.ReadLine();

                    Console.Write("Enter Address: ");
                    Address = Console.ReadLine();

                    Console.Write("Enter Number of skill:");
                    n = int.Parse(Console.ReadLine());

                    Console.WriteLine("Enter Skills : ");
                    InputSkills = new string[n];
                    for (int i = 0; i < n; i++)
                        InputSkills[i] = Console.ReadLine();

                    Console.WriteLine("\n");
                    Console.Clear();

                    TechnicalEmployee TechEmp_1 = new TechnicalEmployee(Id, Name, Address, InputSkills);
                    Console.WriteLine(TechEmp_1);

                    Console.WriteLine("\n");
                    Console.Write("Do u want to Change address??? (y/n): ");
                    string c = Console.ReadLine();

                    if (c =="y")
                    {
                        Console.Write("Enter Address to be changed: ");
                        string changeAddress = Console.ReadLine();

                        TechEmp_1.SetAddress(changeAddress);

                        Console.Clear();
                        Console.WriteLine(TechEmp_1);
                    }

                    
                }
                catch (FormatException)
                {
                    Console.Clear();
                    Console.WriteLine("\n You have Entered a wrong Format... Enter as Intger Format...");

                }
                catch (Exception ex)
                { 
                    Console.Clear();
                    Console.WriteLine(ex.Message);
                }
            }

            void Staff()
            {
                try
                {
                    Console.Write("Enter Employee ID: ");
                    Id = int.Parse(Console.ReadLine());

                    Console.Write("Enter Employee Name: ");
                    Name = Console.ReadLine();

                    Console.Write("Enter Address: ");
                    Address = Console.ReadLine();

                    Console.Write("Enter Title: ");
                    Title = Console.ReadLine();

                    Console.WriteLine("\n");
                    Console.Clear();

                    StaffMember StaffMem = new StaffMember(Id, Name, Address, Title);
                    Console.WriteLine(StaffMem.ToString());

                    Console.WriteLine("\n");
                    Console.Write("Do u want to Change address??? (y/n): ");
                    string c = Console.ReadLine();

                    if (c == "y")
                    {
                        Console.Write("Enter Address to be changed: ");
                        string changeAddress = Console.ReadLine();

                        StaffMem.SetAddress(changeAddress);

                        Console.Clear();
                        Console.WriteLine(StaffMem);
                    }
                }
                catch (FormatException)
                {
                    Console.Clear();
                    Console.WriteLine("\n You have Entered a wrong Format... Enter as Intger for Emp ID...");
                }
                catch (Exception ex)
                {
                    Console.Clear();
                    Console.WriteLine(ex.Message);
                }

            }

        }
    }
}
