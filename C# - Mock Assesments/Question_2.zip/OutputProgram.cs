﻿using System;

namespace MockAssesment_Question_2
{
    
    class OutputProgram
    {
        static void Main(string[] args)
        {
            string FirstName = "Vignesh";
            string LastName = "Kumarappan";
            string Email = "vigneshkumarappan@gmail.com";
            DateTime Dob = new(1999, 09, 13);

            try
            {
                if ((Email.EndsWith("@mydomain.com") == false))
                    Console.WriteLine("Invalid Email ID \n");

                if ((Dob.Year < 1920) || (Dob.Year > DateTime.Now.Year))
                    Console.WriteLine("Enter a proper Date of Birth \n");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            Person p1 = new Person(FirstName, LastName, Email,Dob);

            Console.WriteLine($@"{p1.FirstName} {p1.LastName} was born on {p1.Dob.ToShortDateString()}. Entered Email ID - {p1.Email}
                                  Is {p1.Adult()} years.
                                  Sun Sign - {p1.SunSign()}.
                                  {p1.Birthday()}
                                  Your Display Name is {p1.ScreenName()}");
            
        }
    }
}
