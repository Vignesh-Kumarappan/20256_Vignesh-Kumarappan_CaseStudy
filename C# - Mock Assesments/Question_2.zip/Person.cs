﻿using System;

namespace MockAssesment_Question_2
{
    class Person
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public DateTime Dob { get; set; }

        public Person(string FirstName, string LastName, string Email, DateTime Dob)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email = Email;
            this.Dob = Dob;
        }

        public Person(string FirstName, string LastName, string Email)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Email = Email;
        }

        public Person(string FirstName, string LastName, DateTime Dob)
        {
            this.FirstName = FirstName;
            this.LastName = LastName;
            this.Dob = Dob;
        }

        public string Adult()
        {
            if (DateTime.Now.Year - Dob.Year > 18)
                return "above 18";
            else
                return "below 18";
        }

        public string SunSign()
        {
            string month = Dob.ToString("MMM");
            int date = int.Parse(Dob.ToString("dd"));
            string ReturnSign = "";

            if (((month == "Mar") && (date >= 21 && date <= 31)) || ((month == "Apr") && (date >= 01 && date <= 19)))
                ReturnSign = "Aires";

            if (((month == "Apr") && (date >= 20 && date <= 31)) || ((month == "May") && (date >= 01 && date <= 20)))
                ReturnSign = "Taurus";

            if (((month == "May") && (date >= 21 && date <= 31)) || ((month == "Jun") && (date >= 01 && date <= 21)))
                ReturnSign = "Gemini";

            if (((month == "Jun") && (date >= 22 && date <= 31)) || ((month == "Jul") && (date >= 01 && date <= 22)))
                ReturnSign = "Cancer";

            if (((month == "Jul") && (date >= 23 && date <= 31)) || ((month == "Aug") && (date >= 01 && date <= 22)))
                ReturnSign = "Leo";

            if (((month == "Aug") && (date >= 23 && date <= 31)) || ((month == "Sep") && (date >= 01 && date <= 22)))
                ReturnSign = "Virgo";

            if (((month == "Sep") && (date >= 23 && date <= 31)) || ((month == "Oct") && (date >= 01 && date <= 23)))
                ReturnSign = "libra";

            if (((month == "Oct") && (date >= 24 && date <= 31)) || ((month == "Nov") && (date >= 01 && date <= 21)))
                ReturnSign = "Scorpius";

            if (((month == "Nov") && (date >= 22 && date <= 31)) || ((month == "Dec") && (date >= 01 && date <= 21)))
                ReturnSign = "Sagittarius";

            if (((month == "Dec") && (date >= 22 && date <= 31)) || ((month == "Jan") && (date >= 01 && date <= 19)))
                ReturnSign = "Capricornus ";

            if (((month == "Jan") && (date >= 20 && date <= 31)) || ((month == "Feb") && (date >= 01 && date <= 18)))
                ReturnSign = "Aquarius";

            if (((month == "Feb") && (date >= 19 && date <= 31)) || ((month == "Mar") && (date >= 01 && date <= 20)))
                ReturnSign = "Pisces";

            return ReturnSign;

        }

        public string Birthday()
        {
            if (DateTime.Now.Date == Dob.Date && DateTime.Now.Month == Dob.Month)
                return "Today is your Birthday..Happy Bithday!!!";
            else
                return "Today is not your Birthday";
        }

        public string ScreenName()
        {
            return (string.Concat(FirstName, LastName, Dob.ToString("dd"), Dob.ToString("MM"), Dob.Year));
        }

    }

}

